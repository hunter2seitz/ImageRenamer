This is a Simple Batch Image File Renamer. 

This program is entirely coded in Python and it reads the directory that will be consist of images. Only .jpg, .jpeg, and .png file extensions. 
While the directory is mounted and the program will automatically renames the image file by the prefix and the incremental number with it. 
